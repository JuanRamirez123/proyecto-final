<?php

$conexion=mysqli_connect("localhost","id20731958_sergio","Sergio#17","id20731958_plantex");

?>